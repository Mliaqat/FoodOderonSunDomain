(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__12a6d2._.css",
    "static/chunks/app_layout_tsx_83fc40._.js"
  ],
  "source": "dynamic"
});
